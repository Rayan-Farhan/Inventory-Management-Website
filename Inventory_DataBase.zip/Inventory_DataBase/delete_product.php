<?php
include 'connection.php'; 
$productid = $_GET['id']; 
$sql = "DELETE FROM products WHERE productid = '$productid'";
if ($conn->query($sql) === TRUE) {
    header('Location: index.php'); 
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>

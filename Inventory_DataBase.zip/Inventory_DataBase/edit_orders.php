<?php
include 'connection.php';
$orderid = $_GET['id'];
$sql = "SELECT * FROM orders WHERE orderid = '$orderid'";
$result = $conn->query($sql);
$order = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $orderdate = $_POST['orderdate'];
    $customers_customerid = $_POST['customers_customerid'];
    $sql = "UPDATE orders SET orderdate = '$orderdate', customers_customerid = '$customers_customerid' WHERE orderid = '$orderid'";
    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Order</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Edit Order</h2>
            <form method="post">
                <label for="orderdate">Order Date:</label><br>
                <input type="date" id="orderdate" name="orderdate" value="<?php echo $order['orderdate']; ?>" required><br><br>

                <label for="customers_customerid">Customer ID:</label><br>
                <input type="text" id="customers_customerid" name="customers_customerid" value="<?php echo $order['customers_customerid']; ?>" required><br><br>

                <input class="btn btn-success" type="submit" value="Update Order">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Orders</a></button>
        </center>
    </div>
</body>
</html>

<?php
include 'connection.php';
$customerid = $_GET['id'];
$sql = "DELETE FROM customer WHERE customerid = '$customerid'";
if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>
<td>
    <button class="btn btn-danger">
        <a href="delete_customer.php?id=<?php echo $customer['customerid']; ?>" onclick="return confirm('Are you sure you want to delete this customer?')">
            Delete
        </a>
    </button>
</td>


<?php
include 'connection.php';
$supplierid = $_GET['id'];
$sql = "SELECT * FROM suppliers WHERE supplierid = '$supplierid'";
$result = $conn->query($sql);
$supplier = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $suppliername = $_POST['suppliername'];
    $contactnumber = $_POST['contactnumber'];
    $sql = "UPDATE suppliers SET suppliername = '$suppliername', contactnumber = '$contactnumber' WHERE supplierid = '$supplierid'";
    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Edit Supplier</h2>
            <form method="post">
                <label for="suppliername">Supplier Name:</label><br>
                <input type="text" id="suppliername" name="suppliername" value="<?php echo $supplier['suppliername']; ?>" required><br><br>

                <label for="contactnumber">Contact Number:</label><br>
                <input type="text" id="contactnumber" name="contactnumber" value="<?php echo $supplier['contactnumber']; ?>"><br><br>

                <input class="btn btn-success" type="submit" value="Update Supplier">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Suppliers</a></button>
        </center>
    </div>
</body>
</html>

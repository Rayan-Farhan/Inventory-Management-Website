<?php
include 'connection.php';
$orderdetailsid = $_GET['id'];
$sql = "SELECT * FROM orderdetails WHERE orderdetailsid = '$orderdetailsid'";
$result = $conn->query($sql);
$orderdetails = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $orders_orderid = $_POST['orders_orderid'];
    $products_productid = $_POST['products_productid'];
    $sql = "UPDATE orderdetails SET quantity = '$quantity', price = '$price', orders_orderid = '$orders_orderid', products_productid = '$products_productid' WHERE orderdetailsid = '$orderdetailsid'";
    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Order Details</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Edit Order Details</h2>
            <form method="post">
                <label for="quantity">Quantity:</label><br>
                <input type="number" id="quantity" name="quantity" value="<?php echo $orderdetails['quantity']; ?>" required><br><br>

                <label for="price">Price:</label><br>
                <input type="number" step="0.01" id="price" name="price" value="<?php echo $orderdetails['price']; ?>" required><br><br>

                <label for="orders_orderid">Order ID:</label><br>
                <input type="text" id="orders_orderid" name="orders_orderid" value="<?php echo $orderdetails['orders_orderid']; ?>" required><br><br>

                <label for="products_productid">Product ID:</label><br>
                <input type="text" id="products_productid" name="products_productid" value="<?php echo $orderdetails['products_productid']; ?>" required><br><br>

                <input class="btn btn-success" type="submit" value="Update Order Details">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Order Details</a></button>
        </center>
    </div>
</body>
</html>

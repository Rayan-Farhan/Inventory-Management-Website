<?php
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $orderdetailsid = $_POST['orderdetailsid'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $orders_orderid = $_POST['orders_orderid'];
    $products_productid = $_POST['products_productid'];
    $sql = $conn->prepare("INSERT INTO orderdetails (orderdetailsid, quantity, price, orders_orderid, products_productid) VALUES (?, ?, ?, ?, ?)");
    $sql->bind_param('sidss', $orderdetailsid, $quantity, $price, $orders_orderid, $products_productid);
    if ($sql->execute()) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Order Details</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Add Order Details</h2>
            <form method="post">
                <label for="orderdetailsid">Order Details ID:</label><br>
                <input type="text" id="orderdetailsid" name="orderdetailsid" required><br><br>

                <label for="quantity">Quantity:</label><br>
                <input type="number" id="quantity" name="quantity" required><br><br>

                <label for="price">Price:</label><br>
                <input type="number" step="0.01" id="price" name="price" required><br><br>

                <label for="orders_orderid">Order ID:</label><br>
                <input type="text" id="orders_orderid" name="orders_orderid" required><br><br>

                <label for="products_productid">Product ID:</label><br>
                <input type="text" id="products_productid" name="products_productid" required><br><br>

                <input class="btn btn-success" type="submit" value="Add Order Details">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Order Details</a></button>
        </center>
    </div>
</body>
</html>

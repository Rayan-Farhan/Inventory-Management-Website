<?php
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplierid = $_POST['supplierid'];
    $suppliername = $_POST['suppliername'];
    $contactnumber = $_POST['contactnumber'];
    $sql = $conn->prepare("INSERT INTO suppliers (supplierid, suppliername, contactnumber) VALUES (?, ?, ?)");
    $sql->bind_param('sss', $supplierid, $suppliername, $contactnumber);
    if ($sql->execute()) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Supplier</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Add New Supplier</h2>
            <form method="post">
                <label for="supplierid">Supplier ID:</label><br>
                <input type="text" id="supplierid" name="supplierid" required><br><br>

                <label for="suppliername">Supplier Name:</label><br>
                <input type="text" id="suppliername" name="suppliername" required><br><br>

                <label for="contactnumber">Contact Number:</label><br>
                <input type="text" id="contactnumber" name="contactnumber"><br><br>

                <input class="btn btn-success" type="submit" value="Add Supplier">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Suppliers</a></button>
        </center>
    </div>
</body>
</html>

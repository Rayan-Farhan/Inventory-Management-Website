<?php
include 'connection.php';
$supplierid = $_GET['id'];
$sql = "DELETE FROM suppliers WHERE supplierid = '$supplierid'";
if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>

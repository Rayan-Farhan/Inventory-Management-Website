<?php
include 'connection.php';
$inventoryid = $_GET['id'];
$sql = "SELECT * FROM inventory WHERE inventoryid = '$inventoryid'";
$result = $conn->query($sql);
$inventory = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stockquantity = $_POST['stockquantity'];
    $products_productid = $_POST['products_productid'];
    $sql = "UPDATE inventory SET stockquantity = '$stockquantity', products_productid = '$products_productid' WHERE inventoryid = '$inventoryid'";
    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Inventory Item</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Edit Inventory Item</h2>
            <form method="post">
                <label for="stockquantity">Stock Quantity:</label><br>
                <input type="number" id="stockquantity" name="stockquantity" value="<?php echo $inventory['stockquantity']; ?>" required><br><br>

                <label for="products_productid">Product ID:</label><br>
                <input type="text" id="products_productid" name="products_productid" value="<?php echo $inventory['products_productid']; ?>" required><br><br>

                <input class="btn btn-success" type="submit" value="Update Inventory">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Inventory</a></button>
        </center>
    </div>
</body>
</html>

<?php
include 'connection.php';
$orderdetailsid= $_GET['id'];
$sql = "DELETE FROM orderdetails WHERE orderdetailsid= '$orderdetailsid'";
if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>
<td>
    <button class="btn btn-danger">
        <a href="delete_orderdetails.php?id=<?php echo $orderdetailsid['orderdetailsid']; ?>" onclick="return confirm('Are you sure you want to delete this order details?')">
            Delete
        </a>
    </button>
</td>


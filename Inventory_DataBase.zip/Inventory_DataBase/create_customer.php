<?php
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerid = $_POST['customerid'];
    $customername = $_POST['customername'];
    $contactnumber = $_POST['contactnumber'];
    $sql = $conn->prepare("INSERT INTO customer (customerid, customername, contactnumber) VALUES (?, ?, ?)");
    $sql->bind_param('sss', $customerid, $customername, $contactnumber);
    if ($sql->execute()) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Customer</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Add New Customer</h2>
            <form method="post">
                <label for="customerid">Customer ID:</label><br>
                <input type="text" id="customerid" name="customerid" required><br><br>
                
                <label for="customername">Customer Name:</label><br>
                <input type="text" id="customername" name="customername" required><br><br>
                
                <label for="contactnumber">Contact Number:</label><br>
                <input type="text" id="contactnumber" name="contactnumber"><br><br>
                
                <input class="btn btn-success" type="submit" value="Add Customer">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Customers List</a></button>
        </center>
    </div>
</body>
</html>

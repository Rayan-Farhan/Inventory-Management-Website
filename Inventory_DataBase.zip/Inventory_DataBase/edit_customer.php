<?php
include 'connection.php';
$customerid = $_GET['id'];
$sql = "SELECT * FROM customer WHERE customerid = '$customerid'";
$result = $conn->query($sql);
$customer = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customername = $_POST['customername'];
    $contactnumber = $_POST['contactnumber'];
    $sql = "UPDATE customer SET customername = '$customername', contactnumber = '$contactnumber' WHERE customerid = '$customerid'";
    if ($conn->query($sql) === TRUE) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Edit Customer</h2>
            <form method="post">
                <label for="customerid">Customer ID:</label><br>
                <!-- Display the ID as read-only since it should not be editable -->
                <input type="text" id="customerid" name="customerid" value="<?php echo $customer['customerid']; ?>" readonly><br><br>
                
                <label for="customername">Customer Name:</label><br>
                <input type="text" id="customername" name="customername" value="<?php echo $customer['customername']; ?>" required><br><br>
                
                <label for="contactnumber">Contact Number:</label><br>
                <input type="text" id="contactnumber" name="contactnumber" value="<?php echo $customer['contactnumber']; ?>"><br><br>
                
                <input class="btn btn-success" type="submit" value="Update Customer">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Customers List</a></button>
        </center>
    </div>
</body>
</html>

<?php
include 'connection.php'; 
$productid = $_GET['id']; 
$sql = "SELECT * FROM products WHERE productid = '$productid'";
$result = $conn->query($sql);
$product = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
    $productname = $_POST['productname'];
    $price = $_POST['price'];
    $suppliers_supplierid = $_POST['suppliers_supplierid'];
    $sql = "UPDATE products SET productname = '$productname', price = '$price', suppliers_supplierid = '$suppliers_supplierid' WHERE productid = '$productid'";
    if ($conn->query($sql) === TRUE) {
        header('Location: index.php'); 
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <center>
            <h2>Edit Product</h2>
            <form method="post">
                <label for="productname">Product Name:</label><br>
                <input type="text" id="productname" name="productname" value="<?php echo $product['productname']; ?>" required><br><br>

                <label for="price">Price:</label><br>
                <input type="number" step="0.01" id="price" name="price" value="<?php echo $product['price']; ?>" required><br><br>

                <label for="suppliers_supplierid">Supplier ID:</label><br>
                <input type="text" id="suppliers_supplierid" name="suppliers_supplierid" value="<?php echo $product['suppliers_supplierid']; ?>" required><br><br>

                <input class="btn btn-success" type="submit" value="Update Product">
            </form>
           <br> 
           <a href="index.php" class="btn btn-primary">Back to Product List</a>

        </center>
    </div>
</body>
</html>

<?php
include 'connection.php'; // Include database connection
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productid = $_POST['productid'];
    $productname = $_POST['productname'];
    $price = $_POST['price'];
    $suppliers_supplierid = $_POST['suppliers_supplierid'];
    $sql = $conn->prepare("INSERT INTO products (productid, productname, price, suppliers_supplierid) VALUES (?, ?, ?, ?)");
    $sql->bind_param('ssds', $productid, $productname, $price, $suppliers_supplierid);
    if ($sql->execute()) {
        header('Location: index.php'); 
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Product</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <center>
            <h2>Add New Product</h2>
            <form method="post">
                <label for="productid">Product ID:</label><br>
                <input type="text" id="productid" name="productid" required><br><br>

                <label for="productname">Product Name:</label><br>
                <input type="text" id="productname" name="productname" required><br><br>

                <label for="price">Price:</label><br>
                <input type="number" step="0.01" id="price" name="price" required><br><br>

                <label for="suppliers_supplierid">Supplier ID:</label><br>
                <input type="text" id="suppliers_supplierid" name="suppliers_supplierid" required><br><br>

                <input class="btn btn-success" type="submit" value="Add Product">
            </form>
            <br>
            <a href="index.php" class="btn btn-primary">Back to Product List</a>

        </center>
    </div>
</body>
</html>

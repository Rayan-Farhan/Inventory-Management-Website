<?php
include 'connection.php';

if (isset($_GET['id'])) {
    $inventoryid = $_GET['id']; // Get the inventory ID from the URL
} else {
    die("Invalid request.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $sql = "DELETE FROM inventory WHERE inventoryid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $inventoryid);

    if ($stmt->execute()) {
        
        header('Location: index.php');
        exit();
    } else {
        echo "Error deleting inventory item: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Delete Inventory Item</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <center>
            <h2>Are you sure you want to delete this inventory item?</h2>
            <form method="post">
                <input type="hidden" name="inventoryid" value="<?php echo htmlspecialchars($inventoryid); ?>">
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
                <a href="index.php" class="btn btn-secondary">Cancel</a>
            </form>
        </center>
    </div>
</body>
</html>


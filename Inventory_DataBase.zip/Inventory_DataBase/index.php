<?php
include 'connection.php'; 

$sort_products = isset($_GET['sort_products']) ? $_GET['sort_products'] : 'productid';
$order_products = isset($_GET['order_products']) && $_GET['order_products'] === 'desc' ? 'DESC' : 'ASC';
$sql_products = "SELECT * FROM products ORDER BY $sort_products $order_products";
$result_products = $conn->query($sql_products);
$products = $result_products->num_rows > 0 ? $result_products->fetch_all(MYSQLI_ASSOC) : [];


$sort_inventory = isset($_GET['sort_inventory']) ? $_GET['sort_inventory'] : 'inventoryid';
$order_inventory = isset($_GET['order_inventory']) && $_GET['order_inventory'] === 'desc' ? 'DESC' : 'ASC';
$sql_inventory = "SELECT * FROM inventory ORDER BY $sort_inventory $order_inventory";
$result_inventory = $conn->query($sql_inventory);
$inventory = $result_inventory->num_rows > 0 ? $result_inventory->fetch_all(MYSQLI_ASSOC) : [];


$sort_customers = isset($_GET['sort_customers']) ? $_GET['sort_customers'] : 'customerid';
$order_customers = isset($_GET['order_customers']) && $_GET['order_customers'] === 'desc' ? 'DESC' : 'ASC';
$sql_customers = "SELECT * FROM customer ORDER BY $sort_customers $order_customers";
$result_customers = $conn->query($sql_customers);
$customers = $result_customers->num_rows > 0 ? $result_customers->fetch_all(MYSQLI_ASSOC) : [];


$sort_suppliers = isset($_GET['sort_suppliers']) ? $_GET['sort_suppliers'] : 'supplierid';
$order_suppliers = isset($_GET['order_suppliers']) && $_GET['order_suppliers'] === 'desc' ? 'DESC' : 'ASC';
$sql_suppliers = "SELECT * FROM suppliers ORDER BY $sort_suppliers $order_suppliers";
$result_suppliers = $conn->query($sql_suppliers);
$suppliers = $result_suppliers->num_rows > 0 ? $result_suppliers->fetch_all(MYSQLI_ASSOC) : [];


$sort_orders = isset($_GET['sort_orders']) ? $_GET['sort_orders'] : 'orderid';
$order_orders = isset($_GET['order_orders']) && $_GET['order_orders'] === 'desc' ? 'DESC' : 'ASC';
$sql_orders = "SELECT * FROM orders ORDER BY $sort_orders $order_orders";
$result_orders = $conn->query($sql_orders);
$orders = $result_orders->num_rows > 0 ? $result_orders->fetch_all(MYSQLI_ASSOC) : [];


$sort_orderdetails = isset($_GET['sort_orderdetails']) ? $_GET['sort_orderdetails'] : 'orderdetailsid';
$order_orderdetails = isset($_GET['order_orderdetails']) && $_GET['order_orderdetails'] === 'desc' ? 'DESC' : 'ASC';
$sql_orderdetails = "SELECT * FROM orderdetails ORDER BY $sort_orderdetails $order_orderdetails";
$result_orderdetails = $conn->query($sql_orderdetails);
$orderdetails = $result_orderdetails->num_rows > 0 ? $result_orderdetails->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Management Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <center>
            <h1>Management Dashboard</h1>
            <a href="forecast.php" class="btn btn-info">Sales Forecast</a>

        </center>

        <!-- Products Table -->
        <h2>Product List</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th><a href="?sort_products=productid&order_products=<?php echo $order_products === 'ASC' ? 'desc' : 'asc'; ?>">Product ID</a></th>
                <th><a href="?sort_products=productname&order_products=<?php echo $order_products === 'ASC' ? 'desc' : 'asc'; ?>">Product Name</a></th>
                <th><a href="?sort_products=price&order_products=<?php echo $order_products === 'ASC' ? 'desc' : 'asc'; ?>">Price</a></th>
                <th>Supplier ID</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($products)): ?>
                <?php foreach ($products as $product): ?>
                <tr>
                    <td><?php echo $product['productid']; ?></td>
                    <td><?php echo $product['productname']; ?></td>
                    <td><?php echo $product['price']; ?></td>
                    <td><?php echo $product['suppliers_supplierid']; ?></td>
                    <td>
                        <a href="edit_product.php?id=<?php echo $product['productid']; ?>" class="btn btn-primary">Edit</a>
                        <a href="delete_product.php?id=<?php echo $product['productid']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No products found</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="create_product.php" class="btn btn-success">Add New Product</a>
        
        <hr>

        <!-- Inventory Table -->
        <h2>Inventory List</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th><a href="?sort_inventory=inventoryid&order_inventory=<?php echo $order_inventory === 'ASC' ? 'desc' : 'asc'; ?>">Inventory ID</a></th>
                <th><a href="?sort_inventory=stockquantity&order_inventory=<?php echo $order_inventory === 'ASC' ? 'desc' : 'asc'; ?>">Stock Quantity</a></th>
                <th>Product ID</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($inventory)): ?>
                <?php foreach ($inventory as $item): ?>
                <tr>
                    <td><?php echo $item['inventoryid']; ?></td>
                    <td>
                        <?php 
                        echo $item['stockquantity'];
                        
                        
                        if ($item['stockquantity'] < 2) {
                            echo " <span style='color: red;'> - Low Stock</span>";
                        }
                        ?>
                    </td>
                    <td><?php echo $item['products_productid']; ?></td>
                    <td>
                        <a href="edit_inventory.php?id=<?php echo $item['inventoryid']; ?>" class="btn btn-primary">Edit</a>
                        <a href="delete_inventory.php?id=<?php echo $item['inventoryid']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No inventory items found</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="create_inventory.php" class="btn btn-success">Add New Inventory</a>
        
        <hr>

        <!-- Customers Table -->
        <h2>Customer List</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th><a href="?sort_customers=customerid&order_customers=<?php echo $order_customers === 'ASC' ? 'desc' : 'asc'; ?>">Customer ID</a></th>
                <th><a href="?sort_customers=customername&order_customers=<?php echo $order_customers === 'ASC' ? 'desc' : 'asc'; ?>">Customer Name</a></th>
                <th>Contact Number</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($customers)): ?>
                <?php foreach ($customers as $customer): ?>
                <tr>
                    <td><?php echo $customer['customerid']; ?></td>
                    <td><?php echo $customer['customername']; ?></td>
                    <td><?php echo $customer['contactnumber']; ?></td>
                    <td>
                        <a href="edit_customer.php?id=<?php echo $customer['customerid']; ?>" class="btn btn-primary">Edit</a>
                        <a href="delete_customer.php?id=<?php echo $customer['customerid']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No customers found</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="create_customer.php" class="btn btn-success">Add New Customer</a>

        <hr>

        <!-- Suppliers Table -->
        <h2>Supplier List</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th><a href="?sort_suppliers=supplierid&order_suppliers=<?php echo $order_suppliers === 'ASC' ? 'desc' : 'asc'; ?>">Supplier ID</a></th>
                <th><a href="?sort_suppliers=suppliername&order_suppliers=<?php echo $order_suppliers === 'ASC' ? 'desc' : 'asc'; ?>">Supplier Name</a></th>
                <th>Contact Number</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($suppliers)): ?>
                <?php foreach ($suppliers as $supplier): ?>
                <tr>
                    <td><?php echo $supplier['supplierid']; ?></td>
                    <td><?php echo $supplier['suppliername']; ?></td>
                    <td><?php echo $supplier['contactnumber']; ?></td>
                    <td>
                        <a href="edit_suppliers.php?id=<?php echo $supplier['supplierid']; ?>" class="btn btn-primary">Edit</a>
                        <a href="delete_suppliers.php?id=<?php echo $supplier['supplierid']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No suppliers found</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="create_suppliers.php" class="btn btn-success">Add New Supplier</a>

        <hr>

        <!-- Orders Table -->
        <h2>Order List</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th><a href="?sort_orders=orderid&order_orders=<?php echo $order_orders === 'ASC' ? 'desc' : 'asc'; ?>">Order ID</a></th>
                <th><a href="?sort_orders=orderdate&order_orders=<?php echo $order_orders === 'ASC' ? 'desc' : 'asc'; ?>">Order Date</a></th>
                <th>Customer ID</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($orders)): ?>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?php echo $order['orderid']; ?></td>
                    <td><?php echo $order['orderdate']; ?></td>
                    <td><?php echo $order['customers_customerid']; ?></td>
                    <td>
                        <a href="edit_orders.php?id=<?php echo $order['orderid']; ?>" class="btn btn-primary">Edit</a>
                        <a href="delete_orders.php?id=<?php echo $order['orderid']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4">No orders found</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="create_orders.php" class="btn btn-success">Add New Order</a>

        <hr>

        <!-- Order Details Table -->
        <h2>Order Details List</h2>
        <table class="table table-striped table-bordered">
            <tr>
                <th><a href="?sort_orderdetails=orderdetailsid&order_orderdetails=<?php echo $order_orderdetails === 'ASC' ? 'desc' : 'asc'; ?>">Order Details ID</a></th>
                <th><a href="?sort_orderdetails=quantity&order_orderdetails=<?php echo $order_orderdetails === 'ASC' ? 'desc' : 'asc'; ?>">Quantity</a></th>
                <th>Order ID</th>
                <th>Product ID</th>
                <th>Action</th>
            </tr>
            <?php if (!empty($orderdetails)): ?>
                <?php foreach ($orderdetails as $detail): ?>
                <tr>
                    <td><?php echo $detail['orderdetailsid']; ?></td>
                    <td><?php echo $detail['quantity']; ?></td>
                    <td><?php echo $detail['orders_orderid']; ?></td>
                    <td><?php echo $detail['products_productid']; ?></td>
                    <td>
                        <a href="edit_orderdetails.php?id=<?php echo $detail['orderdetailsid']; ?>" class="btn btn-primary">Edit</a>
                        <a href="delete_orderdetails.php?id=<?php echo $detail['orderdetailsid']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No order details found</td>
                </tr>
            <?php endif; ?>
        </table>
        <a href="create_orderdetails.php" class="btn btn-success">Add New Order Details</a>
    </div>
</body>
</html>

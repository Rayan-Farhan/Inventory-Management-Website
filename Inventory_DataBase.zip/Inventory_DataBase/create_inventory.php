<?php
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $inventoryid = $_POST['inventoryid'];
    $stockquantity = $_POST['stockquantity'];
    $products_productid = $_POST['products_productid'];
    $sql = $conn->prepare("INSERT INTO inventory (inventoryid, stockquantity, products_productid) VALUES (?, ?, ?)");
    $sql->bind_param('sis', $inventoryid, $stockquantity, $products_productid);
    if ($sql->execute()) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Inventory Item</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Add Inventory Item</h2>
            <form method="post">
                <label for="inventoryid">Inventory ID:</label><br>
                <input type="text" id="inventoryid" name="inventoryid" required><br><br>

                <label for="stockquantity">Stock Quantity:</label><br>
                <input type="number" id="stockquantity" name="stockquantity" required><br><br>

                <label for="products_productid">Product ID:</label><br>
                <input type="text" id="products_productid" name="products_productid" required><br><br>

                <input class="btn btn-success" type="submit" value="Add Inventory Item">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Inventory</a></button>
        </center>
    </div>
</body>
</html>


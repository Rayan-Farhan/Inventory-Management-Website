<?php
include 'connection.php'; 

// Fetch total sales for each order from orders and orderDetails
$sql = "
    SELECT o.orderid, SUM(od.quantity * p.price) AS total_sales
    FROM orders o
    JOIN orderdetails od ON o.orderid = od.orders_orderid
    JOIN products p ON od.products_productid = p.productid
    GROUP BY o.orderid
    ORDER BY o.orderid ASC";
    
$result = $conn->query($sql);

if ($result->num_rows > 5) {
    $sales = [];
    $indices = []; 

    $index = 1; 
    while ($row = $result->fetch_assoc()) {
        $indices[] = $index++;
        $sales[] = $row['total_sales']; 
    }

    $x_mean = array_sum($indices) / count($indices);
    $y_mean = array_sum($sales) / count($sales);

    $numerator = 0;
    $denominator = 0;

    for ($i = 0; $i < count($indices); $i++) {
        $numerator += ($indices[$i] - $x_mean) * ($sales[$i] - $y_mean);
        $denominator += ($indices[$i] - $x_mean) ** 2;
    }

    if ($denominator == 0) {
        echo "<div class='container'>
                <center>
                    <h2>Sales Forecast</h2>
                    <p>Unable to calculate forecast due to insufficient data variability.</p>
                    <a href='index.php' class='btn btn-primary'>Back to Dashboard</a>
                </center>
              </div>";
        exit;
    }

    $slope = $numerator / $denominator; 
    $intercept = $y_mean - ($slope * $x_mean);  
    
    $next_order_index = count($indices) + 1; 
    $forecasted_sales = $slope * $next_order_index + $intercept;

    echo "<div class='container'>
            <center>
                <h2>Company Sales Forecast</h2>
                <p>The forecasted total sales for the next order period is PKR " . number_format($forecasted_sales, 2) . ".</p>
                <a href='index.php' class='btn btn-primary'>Back to Dashboard</a>
            </center>
          </div>";
} else {
    echo "<div class='container'>
            <center>
                <h2>Sales Forecast</h2>
                <p>Not enough order data to forecast total sales. Please add more orders.</p>
                <a href='index.php' class='btn btn-primary'>Back to Dashboard</a>
            </center>
          </div>";
}

$conn->close();
?>
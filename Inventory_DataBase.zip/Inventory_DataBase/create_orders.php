<?php
include 'connection.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $orderid = $_POST['orderid'];
    $orderdate = $_POST['orderdate'];
    $customers_customerid = $_POST['customers_customerid'];
    $sql = $conn->prepare("INSERT INTO orders (orderid, orderdate, customers_customerid) VALUES (?, ?, ?)");
    $sql->bind_param('sss', $orderid, $orderdate, $customers_customerid);
    if ($sql->execute()) {
        header('Location: index.php');
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add New Order</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <center>
            <h2>Add New Order</h2>
            <form method="post">
                <label for="orderid">Order ID:</label><br>
                <input type="text" id="orderid" name="orderid" required><br><br>

                <label for="orderdate">Order Date:</label><br>
                <input type="date" id="orderdate" name="orderdate" required><br><br>

                <label for="customers_customerid">Customer ID:</label><br>
                <input type="text" id="customers_customerid" name="customers_customerid" required><br><br>

                <input class="btn btn-success" type="submit" value="Add Order">
            </form>
            <br>
            <button class="btn btn-primary"><a href="index.php">Back to Orders</a></button>
        </center>
    </div>
</body>
</html>

